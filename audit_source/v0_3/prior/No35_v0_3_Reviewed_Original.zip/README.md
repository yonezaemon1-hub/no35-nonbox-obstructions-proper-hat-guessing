# No.35 candidate v0.3

Non-Box Obstructions for Proper Hat Guessing on Book Graphs

Ryutaro Yonezu / Yonezu Research Lab. 2026-10-24 (Asia/Tokyo).

Working candidate; unrefereed; novelty INCONCLUSIVE; public release HOLD.
The received external v0.1 audit reports PROOF PASS conditional on cited
theorems and COMPUTATION PASS. New v0.2 material is outside that audit.

Start with `REVISION_NOTES.md` (Japanese), then `PROOF.md` (English main argument).
`REFERENCE_VERSION_MAP.md` disambiguates published and arXiv theorem numbers.
`SUPPORT_REDUCTION.md` gives the new restricted-family barrier and search model.

Offline verification requires only Python 3 and the standard library:

```powershell
python .\verify_obstructions.py
python .\verify_revision.py
```

Alternatively run `RUN_VERIFY.ps1`. The verifier uses paths relative to its own file. It requires no API, paid service, GPU or Python package installation. Linux/Python 3.12.14 has been checked; Windows author-machine execution has not.

`verification_results.json` records finite checks for k=3..6. `witness_k3.json` and `witness_k4.json` are explicit proper-tuple certificates. A projection deficiency of one proves that those point sets cannot be covered by the available visible-input slots. This is not a winning-strategy certificate or an exact-value certificate for C_k.

The frozen original v0.1 ZIP is under `prior/`; its SHA256 is checked by
`verify_revision.py`. Frozen witnesses and original verification results remain byte-identical.
The current main verifier changes output routing only; its mathematical checks
are unchanged. Both verifiers write new results and generated witnesses under
`run_outputs/`, leaving the frozen root files untouched. Repeated runs and
different Python/OS descriptions therefore do not alter archived evidence. New checks certify the fixed-family color barrier at
k=3,4 and the k=2 endpoint failure.

Optional exploratory programs are not run by the standard-library verifier:
`search_translation.py` needs `python-sat`, and `search_support.py` needs
`numpy`/`scipy`. Their solver results do not establish a new upper bound or an
exact C_3 value. See the separate result JSON files and SUPPORT_REDUCTION.md.

All rights reserved. Prior constructions and theorems retain the attribution given in PROOF.md. No claim of scholarly priority, journal peer review or proof-assistant formalization is made.

See FIX_v03.md for the v0.2 reproduction bug and regression checks. The v0.2 external audit reports PROOF PASS for its additions, COMPUTATION PARTIAL due to that bug, REFERENCES PASS for numbering, NOVELTY INCONCLUSIVE and RELEASE HOLD. This fix has not received an external audit.
