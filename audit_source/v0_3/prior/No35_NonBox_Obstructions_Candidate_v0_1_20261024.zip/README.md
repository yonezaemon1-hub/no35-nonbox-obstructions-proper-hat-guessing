# No.35 candidate v0.1

Non-Box Obstructions for Proper Hat Guessing on Book Graphs

Ryutaro Yonezu / Yonezu Research Lab. 2026-10-24 (Asia/Tokyo).

Working candidate; unrefereed; novelty INCONCLUSIVE; public release HOLD.

Start with `No35_Gap_Search_Report_20261024.md` (Japanese) and `PROOF.md` (English argument).

Offline verification requires only Python 3 and the standard library:

```powershell
python .\verify_obstructions.py
```

Alternatively run `RUN_VERIFY.ps1`. The verifier uses paths relative to its own file. It requires no API, paid service, GPU or Python package installation. Linux/Python 3.12.14 has been checked; Windows author-machine execution has not.

`verification_results.json` records finite checks for k=3..6. `witness_k3.json` and `witness_k4.json` are explicit proper-tuple certificates. A projection deficiency of one proves that those point sets cannot be covered by the available visible-input slots. This is not a winning-strategy certificate or an exact-value certificate for C_k.

The unrelated preliminary `search_translation.py` requires the optional third-party `python-sat` package. It is not run by the offline verifier. Its two recorded attempts are UNKNOWN and are not used to justify the mathematical candidate.

All rights reserved. Prior constructions and theorems retain the attribution given in PROOF.md. No claim of scholarly priority, journal peer review or proof-assistant formalization is made.
