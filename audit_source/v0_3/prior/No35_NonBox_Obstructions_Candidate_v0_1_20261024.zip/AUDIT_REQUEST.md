# Independent audit request — No.35 candidate v0.1

Please try to refute the statements in PROOF.md before accepting them.

1. Is S_k the already known Gadouleau/He–Ido–Przybocki construction, with cardinality M_k and projection deficiency one? Confirm attribution, including the minimum-cardinality theorem used in Section 6.
2. For every k>=3, does the special label phi_{k-1}(k)=k-1 always avoid equality with the first coordinate on the appended face? Check why k=2 must be excluded.
3. Does coordinatewise injectivity preserve every projection cardinality despite sharing a color between coordinate alphabets?
4. Does the Q=M_k+k^2+1 palette argument defeat every deterministic, vertex-specific strategy at every n? Check all quantifiers and the difference between an obstruction and a winning strategy.
5. Does every non-coverable complete proper box have score at least M_k+k^2+1? Check the harmonic-sum criterion, the integer support bound, and the use of the inherited minimum-cardinality theorem.
6. Is the elementary lower bound M_k+2k valid using the clique theorem HGP(K_k)=2k-1? Do not mistake it for a claimed original theorem.
7. Most importantly, is this precise proper relabeling, additive k^2 upper bound, or negative answer to box extremality already present under another description? Evaluate whether this is a worthwhile short note or merely an immediate known consequence.

Recompute the supplied finite counts and inspect the negative controls. The author's Windows run, an external review, a complete prior-art audit, exact C_3, and HGP(B_{2,5}) are all unclaimed.

Return PROOF / COMPUTATION / REFERENCES / NOVELTY separately. Preserve RELEASE=HOLD pending author review of the audit and the novelty boundary.
